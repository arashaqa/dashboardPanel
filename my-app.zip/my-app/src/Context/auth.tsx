import * as React from 'react';

import { createContext, useContext } from 'react';

interface AuthContext{
    value:any;
}
export const AuthContext = createContext(false);

export function useAuth() {
  return useContext(AuthContext);
}