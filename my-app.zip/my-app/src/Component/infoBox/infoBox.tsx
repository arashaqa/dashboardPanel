import Paper from '@material-ui/core/Paper';
import React from 'react';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';


type props = {
    sellNumber?: Number;
    allSells?: Number;
    messageNumber : Number;
}



export default class InfoBox extends React.Component<props, props> {
    
    
    render() {
        const h3_style ={
            color:'gray'
        }
       
        return (

            <Grid container
                direction="row"
                justifyContent="space-between"
                alignItems="flex-start" spacing={8} >

                <Grid item lg={1} xs={1}>
                </Grid>
                <Grid item
                    lg xs >
                    <div className='infoBox'>
                        <Paper style={{ padding: '5px' }} elevation={3}>
                            <hr />
                            <InfoOutlinedIcon style={{ padding: '5px' }} />
                            <h1>{this.props.sellNumber}</h1>
                            <h3 style={h3_style}>تعداد فروش</h3>
                        </Paper>
                    </div>
                </Grid>
                <Grid item lg xs>
                    <div className='infoBox'>
                        <Paper style={{ padding: '5px' }} elevation={3}>
                            <hr />
                            <InfoOutlinedIcon style={{ padding: '5px' }} />
                            <h1>{this.props.allSells}</h1>
                            <h3 style={h3_style}>کـل فروش</h3>
                        </Paper>
                    </div>
                </Grid>

                <Grid item lg xs >
                    <div className='infoBox'>
                        <Paper style={{ padding: '5px' }} elevation={4}>
                            <hr />
                            <InfoOutlinedIcon style={{ padding: '5px' }} />
                            <h1>{this.props.messageNumber}</h1>
                            <h3 style={h3_style}>پـیـام هــا</h3>
                        </Paper>
                    </div>
                </Grid>
            </Grid>
        );
    }
}

