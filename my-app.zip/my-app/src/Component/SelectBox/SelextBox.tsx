import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import './SelectBox.scss'
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import NativeSelect from '@material-ui/core/NativeSelect';
import InputBase from '@material-ui/core/InputBase';
import * as React from 'react';


const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            width: '130px',
            height: '40px',
            justifyContent: 'center',
            top:'5px',
        },
        margin: {
            margin: theme.spacing(0),
        },
    }),
);

export default function SelectBox() {
    const classes = useStyles();
    const [age, setAge] = React.useState('');
    const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
        setAge(event.target.value as string);
    };
    return (
        <div className='sortBoxes'>
            <FormControl variant="outlined" >
                
                <InputLabel htmlFor="outlined-age-native-simple">همه محصولات</InputLabel>
                <Select 
                    className={classes.root}

                    // value={}
                    onChange={handleChange}
                    label="Age"
                    inputProps={{
                        name: 'Prooduct',
                        id: 'outlined-age-native-simple',
                    }}
                >
                    <option aria-label="محصولات" value="محصولات" >همه</option>
                    <option value={10}>فروش</option>
                    <option value={20}>خرید</option>
                    <option value={30}>معامله</option>
                </Select>
            </FormControl>
        </div>
    );
}

