import './Layout.scss'
import * as React from 'react'
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';
import MiniDrawer from "./rightPanel/rightPanel"
import Avatar from '@material-ui/core/Avatar';
import SelectBox from '../SelectBox/SelextBox';
import { CssBaseline } from '@material-ui/core';
const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            display: 'grid',
            '& > *': {
                margin: theme.spacing(1),
                float: 'left'
            },
        },
    }),
);

type LayoutProps = {
    info: string;
    date: string;
    children?: React.ReactNode;
}
export default class Layout extends React.Component<LayoutProps, LayoutProps>{
    render() {
        return (
            <CssBaseline>
            
            <Container maxWidth="xl">
                <Grid container >
                    <Grid item xs={1} >
                        <MiniDrawer />
                    </Grid>
                    <Grid item lg={11} xs={11} className='sort'>
                        <div className='sortBox'>
                            <Avatar className='avatar' alt="Arash balali" src="/static/images/avatar/1.jpg" />
                            <div className='information'>
                                <h3>{this.props.info}</h3>
                                <h6>{this.props.date}</h6>
                            </div>
                            <SelectBox />
                        </div>
                    </Grid>
                </Grid>
                {this.props.children}

                </Container>
            </CssBaseline>
        )
    }
}

