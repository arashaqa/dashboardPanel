import React, { ReactNode } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid'
import { createTheme, ThemeProvider } from '@material-ui/core/styles';
import { Avatar } from '@material-ui/core';
import './dataGrid.scss';
import productControl from '../productControl/productControl';

const theme = createTheme({
    overrides: {
       
        MuiTableCell: {
     
            root: {

                fontFamily: 'vazir !important',
                textAlign: 'center',
            },
        },
        MuiTable: {
            root: {
                textAlign: 'center',
            },
        },
        MuiTableHead: {
            root: {
                textAlign: 'center',
            },

        },
    },
});


const useStyles = makeStyles({
    table: {
        margin:'20px',
        fontFamily: 'inherit !important',

    },
});

function createData(name: string, Product: string, sumSell: number, avatar: ReactNode) {
    return { name, Product, sumSell, avatar };
}

const rows = [
    createData('ارش بلالی', 'محصول آنلاین', 234, <Avatar />),
    createData('ارش بلالی', 'محصول آنلاین', 234, <Avatar />),
    createData('ارش بلالی', 'محصول آنلاین', 234, <Avatar />),
    createData('ارش بلالی', 'محصول آنلاین', 234, <Avatar />),
    createData('ارش بلالی', 'محصول آنلاین', 234, <Avatar />),
    createData('ارش بلالی', 'محصول آنلاین', 234, <Avatar />),


];

export default function BasicTable() {
    const classes = useStyles();
    return (
        <Grid container
        direction="row"
        justifyContent="space-between"
        alignItems="flex-start" spacing={2} >

        <Grid item lg={1} xs={1}>
        </Grid>
            <Grid className='containerStyle'   xs lg >
                <TableContainer component={Paper} style={{ fontFamily: 'inherit' }}>
                    <Table className={classes.table} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell align="right"></TableCell>
                                <TableCell align="right">کاربر</TableCell>
                                <TableCell align="center">محصول</TableCell>
                                <TableCell align="center">قیمت&nbsp;(تومان)</TableCell>
                            </TableRow>
                        </TableHead>
                        <ThemeProvider theme={theme}>
                            <TableBody>
                                {rows.map((row) => (
                                    <TableRow key={row.name}>
                                        <TableCell component="th" style={{width:"4%"}} role="true">{row.avatar}</TableCell>
                                        <TableCell align="right" component="th" scope="row">
                                            {row.name}
                                        </TableCell>
                                        <TableCell align="center">{row.Product}</TableCell>
                                        <TableCell align="center">{row.sumSell}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </ThemeProvider>
                    </Table>
                </TableContainer>
            </Grid>
        </Grid>

    );
}