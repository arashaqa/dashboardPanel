import React,{useEffect, useState} from 'react';
import { BrowserRouter as Router, Switch, Route, Redirect } from "react-router-dom";
import './App.scss';
import PrivateRoute from './PrivateRoute';
import Dashboard from './Containers/Dashboard/Dashboard'
import SignIn from './Containers/Login/Login'
import { AuthContext, useAuth } from './Context/auth'


type props={
  value ?: void ;
  path ?: string;
  component?:any;
  
}

export const App:any = ({}:props)=>{


  const [token,setToken] =  useState(false)
  useEffect(() =>{
      if (token !== null ){
      setToken(true)
    }
    localStorage.clear();

  },[])


return(
    <AuthContext.Provider value={token}>
         <Router>
            <Switch>
              <Route path='/' exact component={SignIn} />
              <PrivateRoute path="/dashboard" component={Dashboard} />
              <Route render={()=><Redirect to='/'/>}/>
            </Switch>
          </Router>
        </AuthContext.Provider >
  )
}


// type PropsApp = {
  //   path?: string;
  //   value?:  any;
  // }
  // type StateApp = {
    //   token?: string | null;
    //   isLogin?:boolean
    // }
    // // interface PrivateRoute {
      // //   path?: string;
      // // }
      // class App extends React.Component<PropsApp, StateApp> {
        //   constructor({ path }: PropsApp) {
          //     super({ path })
          //     this.state = {
            //       token: null,
            //       isLogin:false,
            //     }
            //   }
            //   componentDidWillMount() {
              //     this.setState({ token: JSON.parse(window.localStorage.getItem('accToken') || "{}") })
              //     console.log(this.state.token)
              //   }
              
              //   render() {
                //     let val_val ;
                //     if (this.state.token !== null) {
                  //      val_val = this.state.isLogin
                  //     }
                  //     console.log(this.state.token)
                  //     return (
                    //       <AuthContext.Provider value={this.state.isLogin}>
                    //         <Router>
                    //           <Switch>
                    //             <Route path='/' exact component={SignIn} />
                    //             <PrivateRoute path="/dashboard" component={Dashboard} />
                    //           </Switch>
                    //         </Router>
                    //       </AuthContext.Provider >
                    //       // <Router>
                    //       //   <Switch>
                    //       //     <Route path='/' exact component={SignIn} />
                    //       //     {/* <Route path='/dashboard' exact component={Dashboard}/> */}
                    //       //     <PrivateRoute path="/admin" component={Dashboard} />
                    //       //   </Switch>
                    //       // </Router>
                    //     )
                    //   }
                    // }
                    
                    // <Router>
                    //   <Switch>
                    //       //     <Route path='/' exact component={SignIn} />
                    //       //     {/* <Route path='/dashboard' exact component={Dashboard}/> */}
                    //       //     <PrivateRoute path="/admin" component={Dashboard} />
                    //       //   </Switch>
                    //       // </Router>
export default App
