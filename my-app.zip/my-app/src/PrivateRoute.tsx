import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { AuthContext, useAuth } from './Context/auth'


interface props {
    component: any;
    path: string;
 
}
function PrivateRoute({ component: Component, ...rest }: props) {
    const isAuthenticated = useAuth();
        console.log(isAuthenticated)
    return (

        <Route
            {...rest} 
            render={props =>
                isAuthenticated ? (
                    <Component {...props} />
                ) : (
                    <Redirect to="/" />
                )
            }
        />
    );
}


export default PrivateRoute;