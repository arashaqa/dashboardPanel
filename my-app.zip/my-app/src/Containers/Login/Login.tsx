import React, { useState } from 'react';
import { Redirect, useHistory } from 'react-router-dom';
import Input from '@mui/material/Input';

import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import ARASH from '../../ARASH.png'
import axios from '../../axios-instance';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import './Login.scss'
function Copyright(props: any) {
  return (
    <Typography variant="body2" color="text.secondary" align="center" {...props}>
      {'حق کپی  © '}
      <Link color="inherit" href="ww.com">

      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

// interface theme{
//   overrides?:ThemeOption;
// }
interface ThemeOptions {
  status?: {
    danger?: React.CSSProperties['color']
  }
}
const theme = createTheme({


});


export default function SignIn() {
  const [pass, setPass] = useState([] as any);
  const [user, setUser] = useState([] as any);
  const [tokens, setToken] = useState([] as any);
  const [open, setOpen] = useState(false);

  let history = useHistory()
  const handleClickOpen = () => {
    setOpen(!open);
  };


  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    axios.post('/api-login/', {
      username: user,
      password: pass,

    },
      {
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        }
      }

    ).then(data => {
      setToken(data.data.data.access_token)
      window.localStorage.setItem('accToken',JSON.stringify(data.data.data.access_token))

      tokens !== null ? history.push("/dashboard") : history.push('/')
    })
      .catch(e => setOpen(true))

  }
    const font = {
    fontFamily: 'inherit!important'
  }

  const boxStyle = {
    boxShadow: '0px 0px 25px 0px #EBEBEB',
    padding: '18px',
    borderRadius: '10px',
    fontFamily: 'inherit'
  }
  return (

    <ThemeProvider theme={theme}>

      <Dialog
        open={open}
        onClose={handleClickOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent>

          <DialogTitle id="alert-dialog-title">
            <h5> خطایی رخ داده یا اطلاعات شما اشتباه است  </h5>
           
          </DialogTitle>


        </DialogContent>
          <Button id="btnErr" style={{margin:'0 auto'}} onClick={handleClickOpen}>متوجه شدم !</Button>

      </Dialog>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >

          <img className="loginLogo" src={ARASH} />

          <Box style={boxStyle} component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
            <h1 style={{ textAlign: 'center' }}>ورود</h1>
            <h4 style={{ padding: '2px', margin: '0px', fontSize: '17px' }}>نام کاربری</h4>
            <TextField
              margin="normal"
              name="نام کاربری"
              required
              fullWidth

              onChange={e => setUser(e.target.value)} />
            <h4 style={{ padding: '2px', margin: '0px', fontSize: '17px' }}>رمز عبور</h4>
            <TextField
              style={font}
              margin="normal"
              required
              fullWidth
              name="password"
              type="password"
              id="password"
              autoComplete="current-password"
              onChange={e => setPass(e.target.value)}
            />
            <FormControlLabel

              control={<Checkbox value="remember" color="primary" />}
              label="مرا به خاطر بسپار "

            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
              style={{
                backgroundColor: 'orange',
                borderRadius: '30px',
                fontSize: '17px',
                fontFamily: 'inherit'
              }}

            >
              ورود
            </Button>
            <Grid container>
              <Grid item xs>

              </Grid>
              <Grid item>

              </Grid>
            </Grid>
          </Box>
        </Box>
        <Copyright sx={{ mt: 8, mb: 4 }} />
      </Container>
    </ThemeProvider>
  );
}
