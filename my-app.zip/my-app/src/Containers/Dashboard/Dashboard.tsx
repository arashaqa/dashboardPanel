import React,{ReactNode} from 'react'
import Main from '../../Containers/Main'
import Layout from '../../Component/Layout/Layout';
import InfoBox from '../../Component/infoBox/infoBox';
import DatGrids from '../../Component/DataGrid/dataGrid';


interface DashboardProps {
    info?:string;
    date?: string;
    children?: ReactNode;
}
 
interface DashboardState {
    user: string;
    date: string;
    infoBox: {
      sellNumber: number;
      allSells: number;
      messageNumber: number;
    }
}

 
class Dashboard extends React.Component<DashboardProps, DashboardState> {
    constructor({info}:DashboardProps) {
        super({info})
      this.state= {
        user: 'ارش بلالی',
        date: '1400/2/2',
        infoBox: {
          sellNumber: 526,
          allSells: 256,
          messageNumber: 322,
        },
      }
    }    
    componentDidMount(){
      localStorage.clear()
    }
    render() { 
        return (  
        
            <Main>
                <Layout date={this.state.date} info={this.state.user} >
                <InfoBox sellNumber={this.state.infoBox.sellNumber} allSells={this.state.infoBox.allSells} messageNumber={this.state.infoBox.messageNumber} />
                <DatGrids />
                </Layout>
            </Main>
        </> );
    }
}
 
export default Dashboard;